#!/bin/sh
./configure --cc=g++ --host-cc=g++
